﻿namespace front_end_kpl.view
{
    partial class HalamanAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            button11 = new Button();
            label6 = new Label();
            button12 = new Button();
            label7 = new Label();
            button13 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Highlight;
            panel1.Controls.Add(label1);
            panel1.Location = new Point(0, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(1345, 100);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 36F);
            label1.Location = new Point(272, 6);
            label1.Name = "label1";
            label1.Size = new Size(302, 65);
            label1.TabIndex = 0;
            label1.Text = "Admin Menu";
            // 
            // button1
            // 
            button1.Location = new Point(22, 169);
            button1.Name = "button1";
            button1.Size = new Size(196, 38);
            button1.TabIndex = 1;
            button1.Text = "Add Admin";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(22, 229);
            button2.Name = "button2";
            button2.Size = new Size(196, 38);
            button2.TabIndex = 2;
            button2.Text = "Edit Admin";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(22, 288);
            button3.Name = "button3";
            button3.Size = new Size(196, 42);
            button3.TabIndex = 3;
            button3.Text = "Delete Admin";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(272, 169);
            button4.Name = "button4";
            button4.Size = new Size(196, 38);
            button4.TabIndex = 4;
            button4.Text = "Add Doctor";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(272, 229);
            button5.Name = "button5";
            button5.Size = new Size(196, 38);
            button5.TabIndex = 5;
            button5.Text = "Edit Doctor";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(272, 292);
            button6.Name = "button6";
            button6.Size = new Size(196, 38);
            button6.TabIndex = 6;
            button6.Text = "Delete Doctor";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(505, 169);
            button7.Name = "button7";
            button7.Size = new Size(196, 38);
            button7.TabIndex = 7;
            button7.Text = "Add Patient";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(505, 229);
            button8.Name = "button8";
            button8.Size = new Size(196, 38);
            button8.TabIndex = 8;
            button8.Text = "Edit Patient";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(505, 292);
            button9.Name = "button9";
            button9.Size = new Size(196, 38);
            button9.TabIndex = 9;
            button9.Text = "Delete Patient";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(286, 402);
            button10.Name = "button10";
            button10.Size = new Size(182, 52);
            button10.TabIndex = 10;
            button10.Text = "Appoiment Management";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F);
            label2.Location = new Point(22, 126);
            label2.Name = "label2";
            label2.Size = new Size(204, 30);
            label2.TabIndex = 1;
            label2.Text = "Admin Management";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15.75F);
            label3.Location = new Point(272, 126);
            label3.Name = "label3";
            label3.Size = new Size(206, 30);
            label3.TabIndex = 11;
            label3.Text = "Doctor Management";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15.75F);
            label4.Location = new Point(505, 126);
            label4.Name = "label4";
            label4.Size = new Size(207, 30);
            label4.TabIndex = 12;
            label4.Text = "Patient Management";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 15.75F);
            label5.Location = new Point(260, 356);
            label5.Name = "label5";
            label5.Size = new Size(246, 30);
            label5.TabIndex = 13;
            label5.Text = "Appoiment Management";
            // 
            // button11
            // 
            button11.Location = new Point(286, 477);
            button11.Name = "button11";
            button11.Size = new Size(182, 52);
            button11.TabIndex = 14;
            button11.Text = "Logout";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 15.75F);
            label6.Location = new Point(592, 356);
            label6.Name = "label6";
            label6.Size = new Size(197, 30);
            label6.TabIndex = 15;
            label6.Text = "Room Management";
            label6.Click += label6_Click;
            // 
            // button12
            // 
            button12.Location = new Point(603, 402);
            button12.Margin = new Padding(3, 2, 3, 2);
            button12.Name = "button12";
            button12.Size = new Size(189, 52);
            button12.TabIndex = 16;
            button12.Text = "Room Management";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 14F);
            label7.Location = new Point(4, 359);
            label7.Name = "label7";
            label7.Size = new Size(246, 25);
            label7.TabIndex = 17;
            label7.Text = "Specialization Management";
            // 
            // button13
            // 
            button13.Location = new Point(22, 402);
            button13.Name = "button13";
            button13.Size = new Size(182, 52);
            button13.TabIndex = 18;
            button13.Text = "Specialization Management";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // HalamanAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(844, 630);
            Controls.Add(button13);
            Controls.Add(label7);
            Controls.Add(button12);
            Controls.Add(label6);
            Controls.Add(button11);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(panel1);
            Name = "HalamanAdmin";
            Text = "HalamanAdmin";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button button11;
        private Label label6;
        private Button button12;
        private Label label7;
        private Button button13;
    }
}